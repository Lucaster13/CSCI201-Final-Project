package application2;

public class ViewQuestionsController {

}
